﻿#define _CRT_SECURE_NO_WARNINGS		//防报错
#undef UNICODE		//字符编码形式
#undef _UNICODE
#define PLAYER 1	//文件中的各个元素
#define BOX 2
#define CROSS 3
#define ROAD 4
#define WALL 5
#define PLAYER_ON_CROSS 6
#define BOX_ON_CROSS 7
#define LOGIN 0
#define HOME 1
#define CHOOSE 2
#define GAME 3
#define RECORD 4

#include<stdio.h>		//标准IO
#include<stdlib.h>		//标准库
#include<conio.h>		//控制台IO
#include<graphics.h>	//图形库

typedef struct COORDINATE
{
	int x;
	int y;
}Position;
typedef struct UserMessage
{
	char name[10];
	char password[30];
}User;

int InArea(ExMessage *msg, int x, int y, int width, int height)			//检测鼠标是否在某范围并返回一个值 
{
	if (msg->x > x && msg->x < x + width && msg->y > y && msg->y < y + height)
		return 1;
	return 0;
}

int main()
{
	char key;
	char build_user;
	char login_name[10];
	char str[10], level_name[30];
	char name[10], password[30];
	int user_id, user_number;
	int n = 0, page = 0, level, level_number;
	int xrect, yrect, rect_number;
	int step, actual_step;
	int i, reached;
	int loaded = 0;
	int x_player, y_player;
	int number_cross = 0;
	int x, y;
	int base[10][10] = { 0 };
	int copy[10][10] = { 0 };
	IMAGE main, choose, login;
	IMAGE background, player, player_on_cross, box, wall, road, cross;
	FILE *fp_level, *fp_password;
	FILE *p_popen;
	ExMessage msg;
	Position position_cross[10];
	User user[] = { NULL };
	initgraph(640, 640);
	while(true)
	{
		cleardevice();
		while (LOGIN == page){
			BeginBatchDraw();
			loadimage(&login, "./image/Push_Box.png", 640, 640);
			putimage(0, 0, &login);
			EndBatchDraw();
			fp_password = fopen("password.txt", "r+");
			if (fp_password == NULL){
				perror("\nerror!");
				exit(0);
			}
			user_id = 0;
			user_number = 0;
			while (!feof(fp_password)){
				fscanf(fp_password, "%s %s", user[user_id].name, user[user_id].password);
				user_id++;
			}
			user_number = user_id;
			InputBox(&build_user, 10, _TEXT(""), _TEXT("新建账户?（Y/n）"), _TEXT(""), 200, 30, false);
			if ('y' == build_user || 'Y' == build_user){
				InputBox(name, 10, _TEXT("不超过10个字符"), _TEXT("用户名"), _TEXT(""), 200, 30, false);
				InputBox(password, 30, _TEXT("不超过30个字符"), _TEXT("密码"), _TEXT(""), 200, 30, false);
				fprintf(fp_password, "%s %s\n", name, password);
				page = HOME;
				strcpy(login_name, name);
			}
			else if ('n' == build_user || 'N' == build_user){
				InputBox(name, 10, _TEXT(""), _TEXT("用户名"), _TEXT(""), 200, 30, false);
				InputBox(password, 30, _TEXT(""), _TEXT("密码"), _TEXT(""), 200, 30, false);
				for (user_id = 0; user_id < user_number; user_id++){
					if ((0 == strcmp(user[user_id].name, name)) && (0 == strcmp(user[user_id].password, password))){
						page = HOME;
						strcpy(login_name, name);
					}
				}
			}
			fclose(fp_password);
		}
		cleardevice();
		while (HOME == page){
			BeginBatchDraw();		//开始绘图
			loadimage(&main, "./image/main.png");	//加载主界面
			putimage(0, 0, &main);		//输出主界面
			InArea(&msg, 0, 0, 200, 50) ? settextcolor(RGB(0, 0, 0)) : settextcolor(RGB(255, 255, 255));
			setbkmode(TRANSPARENT);
			settextstyle(32, 0, "黑体");
			outtextxy(0, 0, _TEXT("开始游戏"));
			InArea(&msg, 0, 50, 200, 50) ? settextcolor(RGB(0, 0, 0)) : settextcolor(RGB(255, 255, 255));
			setbkmode(TRANSPARENT);
			settextstyle(32, 0, "黑体");
			outtextxy(0, 50, _TEXT("选择关卡"));
			InArea(&msg, 0, 100, 200, 50) ? settextcolor(RGB(0, 0, 0)) : settextcolor(RGB(255, 255, 255));
			setbkmode(TRANSPARENT);
			settextstyle(32, 0, "黑体");
			outtextxy(0, 100, _TEXT("结束游戏"));
			while (peekmessage(&msg, EM_MOUSE)){
				if (msg.message == WM_LBUTTONDOWN){
					if (InArea(&msg, 0, 0, 200, 50)){	//开始游戏
						page = GAME;
						level = 1;
						loaded = 0;
					}
					if (InArea(&msg, 0, 50, 200, 50)) {//选择关卡
						page = CHOOSE;
						p_popen = _popen("dir level /b /a-d | find /v /c \"\"", "r");
						fscanf(p_popen, "%d", &level_number);
						_pclose(p_popen);
					}
					if (InArea(&msg, 0, 100, 200, 50))	//结束游戏
						exit(0);
				}
			}
			EndBatchDraw();		//结束绘图
		}
		cleardevice();
		while (CHOOSE == page){//选关界面
			BeginBatchDraw();
			loadimage(&choose, "./image/choose.png");	//加载选关界面
			putimage(0, 0, &choose);		//输出选关界面
			for (yrect = 0, xrect = 0, rect_number = 0; rect_number < level_number; ){
				loadimage(&box, "./image/box.png", 116, 116);
				putimage(xrect + 10, yrect + 10, &box);
				settextcolor(RGB(0, 0, 0));
				setbkmode(TRANSPARENT);
				settextstyle(64, 0, "黑体");
				sprintf(str, "%d", rect_number + 1);
				outtextxy(xrect + 10, yrect + 10, str);
				rect_number++;
				xrect += 126;
				if (0 == rect_number % 5){
					xrect = 0;
					yrect += 126;
				}
			}
			if ((msg.x % 126 > 10) && (msg.y % 126 > 10) && (((msg.x / 126) + 1) + 5 * (msg.y / 126)) <= level_number){
				if (InArea(&msg, (msg.x / 126) * 126 + 10, (msg.y / 126) * 126 + 10, 116, 116)){
					setfillcolor(RGB(0, 255, 0));
					solidrectangle((msg.x / 126) * 126 + 10, (msg.y / 126) * 126 + 10, (msg.x / 126) * 126 + 10 + 116, (msg.y / 126) * 126 + 10 + 116);
				}
			}
			while (peekmessage(&msg, EM_MOUSE)){
				if (msg.message == WM_LBUTTONDOWN){
					level = ((msg.x / 126) + 1) + 5 * (msg.y / 126);
					printf("%d\n", level);
					page = GAME;
					loaded = 0;
					break;
				}
			}
			EndBatchDraw();
		}
		cleardevice();
		while (GAME == page){
			BeginBatchDraw();
			loadimage(&choose, "./image/choose.png");
			putimage(0, 0, &choose);
			if (0 == loaded){		//载入地图数据
				step = actual_step = 0;
				strcpy(level_name, "./level/level_");
				sprintf(str, "%d.txt", level);
				strcat(level_name, str);
				fp_level = fopen(level_name, "r");
				if (fp_level == NULL){
					perror("\nerror!");
					exit(0);
				}
				for (y = 0, number_cross = 0; y < 10; y++){
					for (x = 0; x < 10; x++){
						fscanf(fp_level, "%d", &base[x][y]);
						copy[x][y] = base[x][y];
						if (PLAYER == base[x][y]){
							x_player = x;
							y_player = y;
						}
						if (CROSS == base[x][y] || PLAYER_ON_CROSS == base[x][y] || BOX_ON_CROSS == base[x][y]){
							position_cross[number_cross].x = x;
							position_cross[number_cross].y = y;
							number_cross++;
						}
					}
				}
				fclose(fp_level);
				loaded = 1;
			}
			for (y = 0; y < 10; y++){		//加载图片
				for (x = 0; x < 10; x++){
					if (PLAYER == base[x][y]){
						loadimage(&player, "./image/player.png", 64, 64);
						putimage(x * 64, y * 64, &player);
					}
					if (BOX == base[x][y]){
						loadimage(&box, "./image/box.png", 64, 64);
						putimage(x * 64, y * 64, &box);
					}
					if (CROSS == base[x][y]){
						loadimage(&cross, "./image/cross.png", 64, 64);
						putimage(x * 64, y * 64, &cross);
					}
					if (ROAD == base[x][y]){
						loadimage(&road, "./image/road.png", 64, 64);
						putimage(x * 64, y * 64, &road);
					}
					if (WALL == base[x][y]){
						loadimage(&wall, "./image/wall.png", 64, 64);
						putimage(x * 64, y * 64, &wall);
					}
					if (PLAYER_ON_CROSS == base[x][y]){
						loadimage(&player_on_cross, "./image/player_on_cross.png", 64, 64);
						putimage(x * 64, y * 64, &player_on_cross);
					}
					if (BOX_ON_CROSS == base[x][y]){
						loadimage(&box, "./image/box.png", 64, 64);
						putimage(x * 64, y * 64, &box);
					}
				}
			}
			if (_kbhit())		//检测键盘输入并实现控制人物移动
			{
				actual_step++;
				key = _getch();
				if (72 == key)		//上
				{
					if (PLAYER == base[x_player][y_player] && ROAD == base[x_player][y_player - 1]){
						base[x_player][y_player - 1] = PLAYER;
						base[x_player][y_player] = ROAD;
						y_player--;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && ROAD == base[x_player][y_player - 1]){
						base[x_player][y_player - 1] = PLAYER;
						base[x_player][y_player] = CROSS;
						y_player--;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && CROSS == base[x_player][y_player - 1]){
						base[x_player][y_player - 1] = PLAYER_ON_CROSS;
						base[x_player][y_player] = ROAD;
						y_player--;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && CROSS == base[x_player][y_player - 1]){
						base[x_player][y_player - 1] = PLAYER_ON_CROSS;
						base[x_player][y_player] = CROSS;
						y_player--;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && BOX == base[x_player][y_player - 1] && ROAD == base[x_player][y_player - 2]){
						base[x_player][y_player - 2] = BOX;
						base[x_player][y_player - 1] = PLAYER;
						base[x_player][y_player] = ROAD;
						y_player--;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && BOX_ON_CROSS == base[x_player][y_player - 1] && ROAD == base[x_player][y_player - 2]){
						base[x_player][y_player - 2] = BOX;
						base[x_player][y_player - 1] = PLAYER_ON_CROSS;
						base[x_player][y_player] = ROAD;
						y_player--;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && BOX == base[x_player][y_player - 1] && ROAD == base[x_player][y_player - 2]){
						base[x_player][y_player - 2] = BOX;
						base[x_player][y_player - 1] = PLAYER;
						base[x_player][y_player] = CROSS;
						y_player--;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && BOX_ON_CROSS == base[x_player][y_player - 1] && ROAD == base[x_player][y_player - 2]){
						base[x_player][y_player - 2] = BOX;
						base[x_player][y_player - 1] = PLAYER_ON_CROSS;
						base[x_player][y_player] = CROSS;
						y_player--;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && BOX == base[x_player][y_player - 1] && CROSS == base[x_player][y_player - 2]){
						base[x_player][y_player - 2] = BOX_ON_CROSS;
						base[x_player][y_player - 1] = PLAYER;
						base[x_player][y_player] = ROAD;
						y_player--;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && BOX_ON_CROSS == base[x_player][y_player - 1] && CROSS == base[x_player][y_player - 2]){
						base[x_player][y_player - 2] = BOX_ON_CROSS;
						base[x_player][y_player - 1] = PLAYER_ON_CROSS;
						base[x_player][y_player] = ROAD;
						y_player--;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && BOX == base[x_player][y_player - 1] && CROSS == base[x_player][y_player - 2]){
						base[x_player][y_player - 2] = BOX_ON_CROSS;
						base[x_player][y_player - 1] = PLAYER;
						base[x_player][y_player] = CROSS;
						y_player--;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && BOX_ON_CROSS == base[x_player][y_player - 1] && CROSS == base[x_player][y_player - 2]){
						base[x_player][y_player - 2] = BOX_ON_CROSS;
						base[x_player][y_player - 1] = PLAYER_ON_CROSS;
						base[x_player][y_player] = CROSS;
						y_player--;
						step++;
						break;
					}
				}
				if (80 == key){		//下
					if (PLAYER == base[x_player][y_player] && ROAD == base[x_player][y_player + 1]){
						base[x_player][y_player + 1] = PLAYER;
						base[x_player][y_player] = ROAD;
						y_player++;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && ROAD == base[x_player][y_player + 1]){
						base[x_player][y_player + 1] = PLAYER;
						base[x_player][y_player] = CROSS;
						y_player++;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && CROSS == base[x_player][y_player + 1]){
						base[x_player][y_player + 1] = PLAYER_ON_CROSS;
						base[x_player][y_player] = ROAD;
						y_player++;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && CROSS == base[x_player][y_player + 1]){
						base[x_player][y_player + 1] = PLAYER_ON_CROSS;
						base[x_player][y_player] = CROSS;
						y_player++;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && BOX == base[x_player][y_player + 1] && ROAD == base[x_player][y_player + 2]){
						base[x_player][y_player + 2] = BOX;
						base[x_player][y_player + 1] = PLAYER;
						base[x_player][y_player] = ROAD;
						y_player++;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && BOX_ON_CROSS == base[x_player][y_player + 1] && ROAD == base[x_player][y_player + 2]){
						base[x_player][y_player + 2] = BOX;
						base[x_player][y_player + 1] = PLAYER_ON_CROSS;
						base[x_player][y_player] = ROAD;
						y_player++;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && BOX == base[x_player][y_player + 1] && ROAD == base[x_player][y_player + 2]){
						base[x_player][y_player + 2] = BOX;
						base[x_player][y_player + 1] = PLAYER;
						base[x_player][y_player] = CROSS;
						y_player++;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && BOX_ON_CROSS == base[x_player][y_player + 1] && ROAD == base[x_player][y_player + 2]){
						base[x_player][y_player + 2] = BOX;
						base[x_player][y_player + 1] = PLAYER_ON_CROSS;
						base[x_player][y_player] = CROSS;
						y_player++;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && BOX == base[x_player][y_player + 1] && CROSS == base[x_player][y_player + 2]){
						base[x_player][y_player + 2] = BOX_ON_CROSS;
						base[x_player][y_player + 1] = PLAYER;
						base[x_player][y_player] = ROAD;
						y_player++;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && BOX_ON_CROSS == base[x_player][y_player + 1] && CROSS == base[x_player][y_player + 2]){
						base[x_player][y_player + 2] = BOX_ON_CROSS;
						base[x_player][y_player + 1] = PLAYER_ON_CROSS;
						base[x_player][y_player] = ROAD;
						y_player++;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && BOX == base[x_player][y_player + 1] && CROSS == base[x_player][y_player + 2]){
						base[x_player][y_player + 2] = BOX_ON_CROSS;
						base[x_player][y_player + 1] = PLAYER;
						base[x_player][y_player] = CROSS;
						y_player++;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && BOX_ON_CROSS == base[x_player][y_player + 1] && CROSS == base[x_player][y_player + 2]){
						base[x_player][y_player + 2] = BOX_ON_CROSS;
						base[x_player][y_player + 1] = PLAYER_ON_CROSS;
						base[x_player][y_player] = CROSS;
						y_player++;
						step++;
						break;
					}
				}
				if (75 == key){	//左{
					if (PLAYER == base[x_player][y_player] && ROAD == base[x_player - 1][y_player]){
						base[x_player - 1][y_player] = PLAYER;
						base[x_player][y_player] = ROAD;
						x_player--;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && ROAD == base[x_player - 1][y_player]){
						base[x_player - 1][y_player] = PLAYER;
						base[x_player][y_player] = CROSS;
						x_player--;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && CROSS == base[x_player - 1][y_player]){
						base[x_player - 1][y_player] = PLAYER_ON_CROSS;
						base[x_player][y_player] = ROAD;
						x_player--;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && CROSS == base[x_player - 1][y_player]){
						base[x_player - 1][y_player] = PLAYER_ON_CROSS;
						base[x_player][y_player] = CROSS;
						x_player--;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && BOX == base[x_player - 1][y_player] && ROAD == base[x_player - 2][y_player]){
						base[x_player - 2][y_player] = BOX;
						base[x_player - 1][y_player] = PLAYER;
						base[x_player][y_player] = ROAD;
						x_player--;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && BOX_ON_CROSS == base[x_player - 1][y_player] && ROAD == base[x_player - 2][y_player]){
						base[x_player - 2][y_player] = BOX;
						base[x_player - 1][y_player] = PLAYER_ON_CROSS;
						base[x_player][y_player] = ROAD;
						x_player--;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && BOX == base[x_player - 1][y_player] && ROAD == base[x_player - 2][y_player]){
						base[x_player - 2][y_player] = BOX;
						base[x_player - 1][y_player] = PLAYER;
						base[x_player][y_player] = CROSS;
						x_player--;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && BOX_ON_CROSS == base[x_player - 1][y_player] && ROAD == base[x_player - 2][y_player]){
						base[x_player - 2][y_player] = BOX;
						base[x_player - 1][y_player] = PLAYER_ON_CROSS;
						base[x_player][y_player] = CROSS;
						x_player--;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && BOX == base[x_player - 1][y_player] && CROSS == base[x_player - 2][y_player]){
						base[x_player - 2][y_player] = BOX_ON_CROSS;
						base[x_player - 1][y_player] = PLAYER;
						base[x_player][y_player] = ROAD;
						x_player--;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && BOX_ON_CROSS == base[x_player - 1][y_player] && CROSS == base[x_player - 2][y_player]){
						base[x_player - 2][y_player] = BOX_ON_CROSS;
						base[x_player - 1][y_player] = PLAYER_ON_CROSS;
						base[x_player][y_player] = ROAD;
						x_player--;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && BOX == base[x_player - 1][y_player] && CROSS == base[x_player - 2][y_player]){
						base[x_player - 2][y_player] = BOX_ON_CROSS;
						base[x_player - 1][y_player] = PLAYER;
						base[x_player][y_player] = CROSS;
						x_player--;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && BOX_ON_CROSS == base[x_player - 1][y_player] && CROSS == base[x_player - 2][y_player]){
						base[x_player - 2][y_player] = BOX_ON_CROSS;
						base[x_player - 1][y_player] = PLAYER_ON_CROSS;
						base[x_player][y_player] = CROSS;
						x_player--;
						step++;
						break;
					}
				}
				if (77 == key){	//右
					if (PLAYER == base[x_player][y_player] && ROAD == base[x_player + 1][y_player]){
						base[x_player + 1][y_player] = PLAYER;
						base[x_player][y_player] = ROAD;
						x_player++;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && ROAD == base[x_player + 1][y_player]){
						base[x_player + 1][y_player] = PLAYER;
						base[x_player][y_player] = CROSS;
						x_player++;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && CROSS == base[x_player + 1][y_player]){
						base[x_player + 1][y_player] = PLAYER_ON_CROSS;
						base[x_player][y_player] = ROAD;
						x_player++;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && CROSS == base[x_player + 1][y_player]){
						base[x_player + 1][y_player] = PLAYER_ON_CROSS;
						base[x_player][y_player] = CROSS;
						x_player++;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && BOX == base[x_player + 1][y_player] && ROAD == base[x_player + 2][y_player]){
						base[x_player + 2][y_player] = BOX;
						base[x_player + 1][y_player] = PLAYER;
						base[x_player][y_player] = ROAD;
						x_player++;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && BOX_ON_CROSS == base[x_player + 1][y_player] && ROAD == base[x_player + 2][y_player]){
						base[x_player + 2][y_player] = BOX;
						base[x_player + 1][y_player] = PLAYER_ON_CROSS;
						base[x_player][y_player] = ROAD;
						x_player++;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && BOX == base[x_player + 1][y_player] && ROAD == base[x_player + 2][y_player]){
						base[x_player + 2][y_player] = BOX;
						base[x_player + 1][y_player] = PLAYER;
						base[x_player][y_player] = CROSS;
						x_player++;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && BOX_ON_CROSS == base[x_player + 1][y_player] && ROAD == base[x_player + 2][y_player]){
						base[x_player + 2][y_player] = BOX;
						base[x_player + 1][y_player] = PLAYER_ON_CROSS;
						base[x_player][y_player] = CROSS;
						x_player++;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && BOX == base[x_player + 1][y_player] && CROSS == base[x_player + 2][y_player]){
						base[x_player + 2][y_player] = BOX_ON_CROSS;
						base[x_player + 1][y_player] = PLAYER;
						base[x_player][y_player] = ROAD;
						x_player++;
						step++;
						break;
					}
					if (PLAYER == base[x_player][y_player] && BOX_ON_CROSS == base[x_player + 1][y_player] && CROSS == base[x_player + 2][y_player]){
						base[x_player + 2][y_player] = BOX_ON_CROSS;
						base[x_player + 1][y_player] = PLAYER_ON_CROSS;
						base[x_player][y_player] = ROAD;
						x_player++;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && BOX == base[x_player + 1][y_player] && CROSS == base[x_player + 2][y_player]){
						base[x_player + 2][y_player] = BOX_ON_CROSS;
						base[x_player + 1][y_player] = PLAYER;
						base[x_player][y_player] = CROSS;
						x_player++;
						step++;
						break;
					}
					if (PLAYER_ON_CROSS == base[x_player][y_player] && BOX_ON_CROSS == base[x_player + 1][y_player] && CROSS == base[x_player + 2][y_player]){
						base[x_player + 2][y_player] = BOX_ON_CROSS;
						base[x_player + 1][y_player] = PLAYER_ON_CROSS;
						base[x_player][y_player] = CROSS;
						x_player++;
						step++;
						break;
					}
				}
			}
			for (i = 0, reached = 0; i < number_cross; i++)	{	//实时获取达成目标的箱子数
				if (BOX_ON_CROSS == base[position_cross[i].x][position_cross[i].y])
					reached++;
			}
			if (reached == number_cross){		//达成目标数和总目标数比较，判断是否过关并初始化下一关相关变量
				if (level = level_number){
					loaded = 0;
					page = HOME;
					break;
				}
				level++;
				loaded = 0;
				break;
			}
			InArea(&msg, 0, 576, 64, 64) ? settextcolor(RGB(0, 0, 255)) : settextcolor(RGB(255, 255, 255));
			setbkmode(TRANSPARENT);
			settextstyle(16, 0, "黑体");
			outtextxy(0, 576, _TEXT("重新开始"));
			InArea(&msg, 576, 576, 64, 64) ? settextcolor(RGB(0, 0, 255)) : settextcolor(RGB(255, 255, 255));
			setbkmode(TRANSPARENT);
			settextstyle(16, 0, "黑体");
			outtextxy(576, 576, _TEXT("主菜单"));
			while (peekmessage(&msg, EM_MOUSE)){
				if (msg.message == WM_LBUTTONDOWN){
					if (InArea(&msg, 0, 576, 64, 64)){		//重新开始
						for (x = 0; x < 10; x++){
							for (y = 0; y < 10; y++){
								base[x][y] = copy[x][y];
								if (PLAYER == base[x][y]){
									x_player = x;
									y_player = y;
								}
							}
						}
					}
					if (InArea(&msg, 576, 576, 64, 64))			//主菜单
						page = HOME;
				}
			}
			EndBatchDraw();
		}
		while (RECORD == page){
			BeginBatchDraw();
			loadimage(&choose, "./image/choose.png");
			putimage(0, 0, &choose);
			settextcolor(RGB(255, 255, 255));
			setbkmode(TRANSPARENT);
			settextstyle(36, 0, "黑体");
			outtextxy(0, 0, _TEXT("关卡"));
			settextcolor(RGB(255, 255, 255));
			setbkmode(TRANSPARENT);
			settextstyle(36, 0, "黑体");
			outtextxy(160, 0, _TEXT("步数"));
			settextcolor(RGB(255, 255, 255));
			setbkmode(TRANSPARENT);
			settextstyle(36, 0, "黑体");
			outtextxy(320, 0, _TEXT("实际步数"));
			settextcolor(RGB(255, 255, 255));
			setbkmode(TRANSPARENT);
			settextstyle(36, 0, "黑体");
			outtextxy(480, 0, _TEXT("玩家"));
			InArea(&msg, 576, 576, 64, 64) ? settextcolor(RGB(0, 0, 0)) : settextcolor(RGB(255, 255, 255));
			setbkmode(TRANSPARENT);
			settextstyle(16, 0, "黑体");
			outtextxy(576, 576, _TEXT("主菜单"));
			while (peekmessage(&msg, EM_MOUSE)){
				if (msg.message == WM_LBUTTONDOWN){
					if (InArea(&msg, 576, 576, 64, 64))			//主菜单
						page = 1;
				}
			}
			EndBatchDraw();
		}
		cleardevice();
	}
}